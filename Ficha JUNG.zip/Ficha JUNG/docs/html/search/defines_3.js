var searchData=
[
  ['gray',['GRAY',['../graphviewer_8h.html#ae5f70677050eecd8909e0248e07b9e73',1,'graphviewer.h']]],
  ['green',['GREEN',['../graphviewer_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'graphviewer.h']]]
];
