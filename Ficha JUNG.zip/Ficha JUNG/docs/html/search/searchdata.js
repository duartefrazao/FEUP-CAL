var indexSectionsWithContent =
{
  0: "abcdefghilmoprsuwy",
  1: "ceg",
  2: "cefg",
  3: "acdegimrs",
  4: "cdhipsuw",
  5: "bcdglmoprwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

