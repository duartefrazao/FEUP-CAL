var searchData=
[
  ['white',['WHITE',['../graphviewer_8h.html#a87b537f5fa5c109d3c05c13d6b18f382',1,'graphviewer.h']]]
];
