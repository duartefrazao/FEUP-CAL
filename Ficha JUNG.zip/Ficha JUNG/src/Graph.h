
#include "Vertex.h"
#include "Edge.h"
#include "MutablePriorityQueue.h"
#include <vector>
#include <limits>
#include <cfloat>
#include "Location.h"
#include <algorithm>

#define INF std::numeric_limits<double>::max()

template <class T>
double heuristic(Vertex<T> * v1, Vertex<T> *v2){
	Location *t1 = static_cast<Location*>(v1);
	Location *t2 = static_cast<Location*>(v2);

	return t1->distance(t2);
}

template <class V, class E>
class Graph {
	vector<V *> vertexSet;    // vertex set

public:

	Graph<V,E> ();
//	V *findVertex(const V &in) const;
	bool inVertexSet(V *in) const;
	bool addVertex(V *in);
	bool addEdge(V *sourc, V *dest, double w);
	int getNumVertex() const;
	vector<V *> getVertexSet() const;

	// Fp05 - single source
	void dijkstraShortestPath(V *s);
	bool aStarAlgorithm(V *origin, V *dest);
	vector<V *> dijkstra(V *origin, V *dest);
	vector<V *> aStar(V *origin, V *dest);

};


template <class V, class E>
Graph<V,E> ::Graph(){
	V::counter= 0;
}

template <class V, class E>
int Graph<V,E>::getNumVertex() const {
	return vertexSet.size();
}

template <class V, class E>
vector<V *> Graph<V,E>::getVertexSet() const {
	return vertexSet;
}

///*
// * Auxiliary function to find a vertex with a given content.
// */
//template <class V, class E>
//V * Graph<V,E>::findVertex(const V &in) const {
//	for (auto v : vertexSet)
//		if (v->info == in)
//			return v;
//	return NULL;
//}
template <class V, class E>
bool Graph<V,E>::inVertexSet(V *in) const{
		for (auto v : vertexSet)
			if (v == in) return true;

		return false;
}

/*
 *  Adds a vertex with a given content or info (in) to a graph (this).
 *  Returns true if successful, and false if a vertex with that content already exists.
 */
template <class V, class E>
bool Graph<V,E>::addVertex(V *in) {
	if ( inVertexSet(in) != NULL)
		return false;
	vertexSet.push_back(in);
	return true;
}

/*
 * Adds an edge to a graph (this), given the contents of the source and
 * destination vertices and the edge weight (w).
 * Returns true if successful, and false if the source or destination vertex does not exist.
 */
template <class V, class E>
bool Graph<V,E>::addEdge(V *sourc, V *dest, double w) {
	if(!inVertexSet(sourc) || !inVertexSet(dest))
		return false;

	sourc->addEdge(dest,w);
	return true;
}








/**************** Single Source Shortest Path algorithms ************/

template <class V, class E>
void Graph<V,E>::dijkstraShortestPath(V *origin) {
	MutablePriorityQueue<V> g;

	for(V * v : this->vertexSet){
		v->dist =DBL_MAX;
		v->path=NULL;
	}

	V * node = origin;

	node->dist= 0;
	g.insert(node);



	while(!g.empty())
	{
		node = g.extractMin();

		node->inClosedSet=true;

		for(E e:node->adj)
		{
			//Past distance
			double d = e.dest->dist;

			if(node->dist + e.weight < d){

				//New calculated distance
				double newT = node->dist + e.weight;

				e.dest->dist = newT ;
				e.dest->path = node;

				//Se ainda não estava na fila insere-se
				if(d== DBL_MAX ) g.insert(e.dest);
				else g.decreaseKey(e.dest);
			}


		}
	}

}


/**************** A STAR ************/

template <class V, class E>
bool Graph<V,E>::aStarAlgorithm(V *origin, V *dest) {

	MutablePriorityQueue<V> openSet;

	for(auto vertex : vertexSet){
		vertex->f = INF;
		vertex->dist = INF;
		vertex->path = NULL;
		vertex->inClosedSet = false;
		vertex->inOpenSet = false;
	}

	V * end = dest;

	V * start = origin;
	start->dist = 0;
	start->updateF(heuristic, end);
	start->inClosedSet = false;
	start->inOpenSet = true;
	openSet.insert(start);

	while(!openSet.empty()){

		V * v = openSet.extractMin();
		v->inClosedSet = true;
		v->inOpenSet = false;
//		std::cout << "\n\nId: " << v->getId() << std::endl;
		if(v == end){
			return true;
		}

		for(E edge : v->adj){
			V * destV = edge.getDest();
//			std::cout << "IdA: " << destV->getId() << std::endl;
			if(!destV->inClosedSet){
			destV->dist = v->dist + edge.weight;
			destV->path = v;
			destV->updateF(heuristic, end);

			if(!destV->inOpenSet){
				destV->inOpenSet = true;
				openSet.insert(destV);
			}
			else openSet.decreaseKey(destV);
			}
			else{
				if(destV->calculateF(heuristic, end) < destV->f){
					destV->inClosedSet = false;
					destV->dist = v->dist + edge.weight;
					destV->path = v;
					destV->updateF(heuristic, end);
					destV->inOpenSet = true;
					openSet.insert(destV);
				}
			}
		}

	}

	return false;
}

template <class V, class E>
vector<V *> Graph<V,E>::aStar(V *origin, V *dest){

	this->aStarAlgorithm(origin, dest);
	vector<V *> res;
	V * v = dest;

	while(v->path != NULL){
		res.push_back(v);
		v = static_cast<V *>(v->path);
	}

	res.push_back(v);
	std::reverse(res.begin(), res.end());

	return res;
}

template <class V, class E>
vector<V *> Graph<V,E>::dijkstra(V *origin, V *dest){
	this->dijkstraShortestPath(origin);

	vector<V *> res;
	V * v = dest;

	while(v->path != NULL){
		res.push_back(v);
		v = static_cast<V *>(v->path);
	}

	res.push_back(v);
	std::reverse(res.begin(), res.end());

	return res;
}
